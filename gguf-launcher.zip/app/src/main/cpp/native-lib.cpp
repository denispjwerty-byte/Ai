// JNI-мост (этап 2): загрузка GGUF через mmap, потоковая генерация, выгрузка.
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <sstream>
#include <numeric>
#include "llama.h"

#define TAG "GgufNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

std::mutex g_mutex;                 // защищает model/ctx от одновременного доступа
llama_model   *g_model = nullptr;
llama_context *g_ctx   = nullptr;
std::string    g_error;
std::atomic<bool> g_stop{false};
bool g_backend_ready = false;

void log_cb(ggml_log_level level, const char *text, void *) {
    int prio = level == GGML_LOG_LEVEL_ERROR ? ANDROID_LOG_ERROR
             : level == GGML_LOG_LEVEL_WARN  ? ANDROID_LOG_WARN
                                             : ANDROID_LOG_INFO;
    __android_log_write(prio, "llama", text);
}

// В новых версиях llama.cpp поля use_mmap/use_mlock могли пропасть из llama_model_params.
// Ставим их, только если они есть (иначе сборка не падает, работают значения по умолчанию).
template <class T> auto set_mmap(T &p, bool v, int) -> decltype(p.use_mmap = v, bool()) { p.use_mmap = v; return true; }
template <class T> bool set_mmap(T &, bool, long) { return false; }
template <class T> auto set_mlock(T &p, bool v, int) -> decltype(p.use_mlock = v, bool()) { p.use_mlock = v; return true; }
template <class T> bool set_mlock(T &, bool, long) { return false; }

void free_all() {
    if (g_ctx)   { llama_free(g_ctx);         g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

// Длина самого длинного префикса, который является законченным UTF-8.
// Хвост с обрезанным символом остаётся в буфере до следующего токена.
size_t utf8_valid_prefix(const std::string &s) {
    size_t n = s.size();
    if (n == 0) return 0;
    size_t i = n;
    int back = 0;
    while (i > 0 && back < 4) {
        unsigned char c = (unsigned char) s[i - 1];
        if ((c & 0xC0) == 0x80) { i--; back++; continue; }  // продолжение символа
        int need = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
        if (need > back + 1) return i - 1;  // символ не дописан, режем перед ним
        return n;
    }
    return n;
}

} // namespace

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_example_gguflauncher_NativeBridge_systemInfo(JNIEnv *env, jobject) {
    return env->NewStringUTF(llama_print_system_info());
}

// Загрузка модели. true = успех, иначе см. lastError().
JNIEXPORT jboolean JNICALL
Java_com_example_gguflauncher_NativeBridge_load(JNIEnv *env, jobject,
                                                jstring jpath, jint nCtx, jint nThreads, jint kvType) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_error.clear();
    free_all();

    if (!g_backend_ready) {
        llama_log_set(log_cb, nullptr);
        llama_backend_init();
        g_backend_ready = true;
    }

    const char *path = env->GetStringUTFChars(jpath, nullptr);

    llama_model_params mp = llama_model_default_params();
    bool mmap_ok  = set_mmap(mp, true, 0);    // файл отображается в память
    bool mlock_ok = set_mlock(mp, false, 0);  // не закрепляем в ОЗУ
    LOGI("use_mmap field: %d, use_mlock field: %d", (int) mmap_ok, (int) mlock_ok);
    mp.n_gpu_layers = 0;      // на телефоне память общая, GPU-слои ОЗУ не экономят

    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!g_model) {
        g_error = "Не удалось загрузить модель (файл повреждён или нет памяти)";
        return JNI_FALSE;
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx           = nCtx > 0 ? nCtx : 2048;
    cp.n_batch         = 512;
    cp.n_ubatch        = 512;
    cp.n_threads       = nThreads > 0 ? nThreads : 4;
    cp.n_threads_batch = cp.n_threads;
    if (kvType == 1) {                                   // KV-кэш q8_0 (нужен flash attention)
        cp.type_k          = GGML_TYPE_Q8_0;
        cp.type_v          = GGML_TYPE_Q8_0;
        cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    } else {                                             // KV-кэш f16, всё по умолчанию
        cp.type_k          = GGML_TYPE_F16;
        cp.type_v          = GGML_TYPE_F16;
        cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_DISABLED;
    }
    LOGI("KV type: %s", kvType == 1 ? "q8_0" : "f16");

    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        g_error = "Не удалось создать контекст (мало памяти? уменьши n_ctx)";
        free_all();
        return JNI_FALSE;
    }
    LOGI("Модель загружена, n_ctx=%d", (int) llama_n_ctx(g_ctx));
    return JNI_TRUE;
}

// Генерация. Для каждого куска текста вызывает callback.onToken(String): Boolean
// (false = остановить). Возвращает число сгенерированных токенов или -1 при ошибке.
JNIEXPORT jint JNICALL
Java_com_example_gguflauncher_NativeBridge_generate(JNIEnv *env, jobject,
                                                    jstring jprompt, jint maxTokens,
                                                    jfloat temp, jobject callback) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_error.clear();
    g_stop = false;

    if (!g_model || !g_ctx) { g_error = "Модель не загружена"; return -1; }

    jclass cbClass = env->GetObjectClass(callback);
    jmethodID onToken = env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;)Z");
    if (!onToken) { g_error = "В callback нет onToken(String): Boolean"; return -1; }

    const llama_vocab *vocab = llama_model_get_vocab(g_model);

    // Токенизация промпта
    const char *p = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(p);
    env->ReleaseStringUTFChars(jprompt, p);

    std::vector<llama_token> tokens(prompt.size() + 8);
    int n = llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(),
                           tokens.data(), (int) tokens.size(), true, true);
    if (n < 0) {
        tokens.resize(-n);
        n = llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(),
                           tokens.data(), (int) tokens.size(), true, true);
    }
    if (n <= 0) { g_error = "Ошибка токенизации"; return -1; }
    tokens.resize(n);

    const int n_ctx = (int) llama_n_ctx(g_ctx);
    if (n >= n_ctx) { g_error = "Промпт не влезает в контекст"; return -1; }

    // Чистим KV-кэш: пока каждый запрос независим
    llama_memory_clear(llama_get_memory(g_ctx), true);

    // Сэмплер
    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temp <= 0.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    // Префилл промпта кусками по n_batch
    const int n_batch = (int) llama_n_batch(g_ctx);
    for (int i = 0; i < n; i += n_batch) {
        if (g_stop) { llama_sampler_free(smpl); return 0; }
        int cnt = std::min(n_batch, n - i);
        if (llama_decode(g_ctx, llama_batch_get_one(tokens.data() + i, cnt)) != 0) {
            g_error = "llama_decode: ошибка на промпте";
            llama_sampler_free(smpl);
            return -1;
        }
    }

    // Цикл генерации
    int generated = 0;
    int n_past = n;
    std::string pending;   // байты, ещё не ставшие законченным UTF-8
    bool stop_by_cb = false;

    auto flush = [&](bool force) {
        size_t k = force ? pending.size() : utf8_valid_prefix(pending);
        if (k == 0) return;
        std::string out = pending.substr(0, k);
        pending.erase(0, k);
        jstring js = env->NewStringUTF(out.c_str());
        jboolean cont = env->CallBooleanMethod(callback, onToken, js);
        env->DeleteLocalRef(js);
        if (env->ExceptionCheck()) { env->ExceptionClear(); stop_by_cb = true; }
        else if (!cont) stop_by_cb = true;
    };

    while (generated < maxTokens && n_past < n_ctx && !g_stop && !stop_by_cb) {
        llama_token tok = llama_sampler_sample(smpl, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;

        char buf[256];
        int len = llama_token_to_piece(vocab, tok, buf, sizeof(buf), 0, false);
        if (len > 0) pending.append(buf, len);
        flush(false);
        generated++;

        if (llama_decode(g_ctx, llama_batch_get_one(&tok, 1)) != 0) {
            g_error = "llama_decode: ошибка при генерации";
            break;
        }
        n_past++;
    }
    if (!pending.empty() && !stop_by_cb) flush(true);

    llama_sampler_free(smpl);
    return g_error.empty() ? generated : -1;
}

// Остановка генерации (можно звать из любого потока, не ждёт мьютекс).
JNIEXPORT void JNICALL
Java_com_example_gguflauncher_NativeBridge_stop(JNIEnv *, jobject) {
    g_stop = true;
}

// Выгрузка модели. Если идёт генерация, сначала останавливаем и ждём.
JNIEXPORT void JNICALL
Java_com_example_gguflauncher_NativeBridge_unload(JNIEnv *, jobject) {
    g_stop = true;
    std::lock_guard<std::mutex> lock(g_mutex);
    free_all();
    LOGI("Модель выгружена");
}

JNIEXPORT jboolean JNICALL
Java_com_example_gguflauncher_NativeBridge_isLoaded(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_model != nullptr && g_ctx != nullptr;
}


// Диагностика: токенизация туда-обратно, сведения о модели, логиты после промпта (NaN/inf, топ-5).
JNIEXPORT jstring JNICALL
Java_com_example_gguflauncher_NativeBridge_diagnose(JNIEnv *env, jobject, jstring jprompt) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx) return env->NewStringUTF("Модель не загружена");

    std::ostringstream out;
    const llama_vocab *vocab = llama_model_get_vocab(g_model);

    char desc[256];
    llama_model_desc(g_model, desc, sizeof(desc));
    out << "Модель: " << desc << "\n"
        << "слоёв=" << llama_model_n_layer(g_model)
        << " embd=" << llama_model_n_embd(g_model)
        << " vocab=" << llama_vocab_n_tokens(vocab)
        << " n_ctx=" << llama_n_ctx(g_ctx) << "\n";

    const char *p = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(p);
    env->ReleaseStringUTFChars(jprompt, p);

    std::vector<llama_token> tokens(prompt.size() + 8);
    int n = llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(),
                           tokens.data(), (int) tokens.size(), true, true);
    if (n < 0) {
        tokens.resize(-n);
        n = llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(),
                           tokens.data(), (int) tokens.size(), true, true);
    }
    if (n <= 0) { out << "Токенизация не удалась\n"; return env->NewStringUTF(out.str().c_str()); }
    tokens.resize(n);

    out << "Токены (" << n << "): ";
    for (int i = 0; i < n && i < 16; i++) out << tokens[i] << " ";
    std::vector<char> back(prompt.size() * 4 + 64);
    int bl = llama_detokenize(vocab, tokens.data(), n, back.data(), (int) back.size(), false, false);
    out << "\nОбратно: " << (bl > 0 ? std::string(back.data(), bl) : std::string("<пусто>")) << "\n";

    llama_memory_clear(llama_get_memory(g_ctx), true);
    int rc = llama_decode(g_ctx, llama_batch_get_one(tokens.data(), n));
    out << "decode rc=" << rc << "\n";
    if (rc == 0) {
        const float *lg = llama_get_logits_ith(g_ctx, -1);
        int nv = llama_vocab_n_tokens(vocab);
        if (!lg) {
            out << "логиты: nullptr\n";
        } else {
            int nan = 0, inf = 0;
            float mn = 1e30f, mx = -1e30f;
            for (int i = 0; i < nv; i++) {
                float v = lg[i];
                if (std::isnan(v)) nan++;
                else if (std::isinf(v)) inf++;
                else { mn = std::min(mn, v); mx = std::max(mx, v); }
            }
            out << "логиты: NaN=" << nan << " inf=" << inf << " min=" << mn << " max=" << mx << "\n";
            std::vector<int> idx(nv);
            std::iota(idx.begin(), idx.end(), 0);
            std::partial_sort(idx.begin(), idx.begin() + 5, idx.end(),
                              [&](int a, int b) { return lg[a] > lg[b]; });
            out << "Топ-5:\n";
            for (int k = 0; k < 5; k++) {
                char buf[64];
                int l = llama_token_to_piece(vocab, idx[k], buf, sizeof(buf), 0, false);
                out << "  " << idx[k] << " [" << (l > 0 ? std::string(buf, l) : std::string("?"))
                    << "] " << lg[idx[k]] << "\n";
            }
        }
    }
    llama_memory_clear(llama_get_memory(g_ctx), true);
    return env->NewStringUTF(out.str().c_str());
}

JNIEXPORT jstring JNICALL
Java_com_example_gguflauncher_NativeBridge_lastError(JNIEnv *env, jobject) {
    return env->NewStringUTF(g_error.c_str());
}

} // extern "C"
