package com.example.gguflauncher

import android.app.Activity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/** Колбэк потоковой генерации. Вернуть false, чтобы остановить. */
fun interface TokenCallback {
    fun onToken(piece: String): Boolean
}

object NativeBridge {
    init {
        System.loadLibrary("gguflauncher")
    }

    external fun systemInfo(): String
    /** kvType: 0 = f16, 1 = q8_0 */
    external fun load(path: String, nCtx: Int, nThreads: Int, kvType: Int): Boolean
    external fun generate(prompt: String, maxTokens: Int, temp: Float, callback: TokenCallback): Int
    external fun stop()
    external fun unload()
    external fun isLoaded(): Boolean
    external fun lastError(): String
    external fun diagnose(prompt: String): String
}

// Временный экран для проверки моста. Позже заменим на Compose.
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var prompt: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val modelsDir = getExternalFilesDir("models")!!.apply { mkdirs() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 96, 32, 32)
        }
        status = TextView(this).apply {
            textSize = 12f
            text = "Положи .gguf в:\n$modelsDir"
        }
        val btnLoad = Button(this).apply { text = "Загрузить (KV f16)" }
        val btnLoadQ8 = Button(this).apply { text = "Загрузить (KV q8_0)" }
        val btnUnload = Button(this).apply { text = "Выгрузить" }
        prompt = EditText(this).apply { setText("Привет! Расскажи коротко о себе."); textSize = 14f }
        val btnGen = Button(this).apply { text = "Генерировать" }
        val btnStop = Button(this).apply { text = "Стоп" }
        val btnDiag = Button(this).apply { text = "Диагностика" }
        output = TextView(this).apply {
            textSize = 14f
            movementMethod = ScrollingMovementMethod()
        }

        root.addView(status, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(btnLoad); root.addView(btnLoadQ8); root.addView(btnUnload)
        root.addView(prompt, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(btnGen); root.addView(btnStop); root.addView(btnDiag)
        root.addView(output, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)

        fun doLoad(kvType: Int) {
            val file = modelsDir.listFiles { f: File -> f.extension.equals("gguf", true) }
                ?.firstOrNull()
            if (file == null) { status.text = "В $modelsDir нет .gguf"; return }
            status.text = "Загружаю ${file.name}…"
            Thread {
                val t = System.currentTimeMillis()
                val ok = NativeBridge.load(file.absolutePath, 2048, 4, kvType)
                val msg = if (ok) "Готово: ${file.name} (${System.currentTimeMillis() - t} мс)"
                          else "Ошибка: ${NativeBridge.lastError()}"
                runOnUiThread { status.text = msg }
            }.start()
        }
        btnLoad.setOnClickListener { doLoad(0) }
        btnLoadQ8.setOnClickListener { doLoad(1) }

        btnUnload.setOnClickListener {
            Thread {
                NativeBridge.unload()
                runOnUiThread { status.text = "Модель выгружена" }
            }.start()
        }

        btnGen.setOnClickListener {
            output.text = ""
            val text = prompt.text.toString()
            Thread {
                val t = System.currentTimeMillis()
                val n = NativeBridge.generate(text, 256, 0.7f) { piece ->
                    runOnUiThread { output.append(piece) }
                    true
                }
                val msg = if (n >= 0) "Токенов: $n за ${System.currentTimeMillis() - t} мс"
                          else "Ошибка: ${NativeBridge.lastError()}"
                runOnUiThread { status.text = msg }
            }.start()
        }

        btnStop.setOnClickListener { NativeBridge.stop() }

        btnDiag.setOnClickListener {
            val text = prompt.text.toString()
            Thread {
                val r = NativeBridge.diagnose(text)
                runOnUiThread { output.text = r }
            }.start()
        }
    }

    override fun onDestroy() {
        if (isFinishing) Thread { NativeBridge.unload() }.start()
        super.onDestroy()
    }
}
